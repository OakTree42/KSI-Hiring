Current Version is: 0.1.6.0
Updated on: 7.20.2015

This is provided as is.
It is BETA at best.

It over-writes part of the Astronaut Complex with a new hiring platform.

Be aware that it uses code to create new kerbals and you may find some glitches.

In addition be aware that at the moment the kerbals look all the same, with gender changes but still the same.

This mod will be updated. Again WiP use at your own risk!!!

Although I have tested it as best as I can I can not confirm it in all the various situations.

You should always save your game before installing new mods.

In theory this mod should be removable without any issue to your saved game after it is removed but I can not confirm this 100%.

I hope people find this mod useful.

Things planned to be added:

1. Randomized Gender selector
2. Cap on level based on current max level in complex
3. Randomized smarts/fear stats at a discounted rate (More stock like)

Note: I have had people ask for the ability to put the game in 'creative' mode to allow you to hire all the kerbals you want in stock career. I am looking into this. I have also had people ask me to make it so you could have level 1 or such in sandbox. This second one is NOT possible at the moment as any kerbal so created is 'pegged' to level 5 by the game at several points in processing by the stock sandbox mode and that means I would have to rebuild sandbox mode in effect, not something I hope to do soon.


If you find a bug please let me know. 

Also to install simply copy the KSI folder into your GameData folder. Hopefully that should be all you need to do!

OakTree42

Special Thanks to Jon Dahm for helping clean up the latest version of the code.